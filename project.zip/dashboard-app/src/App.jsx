import './App.css';
import DashboardNavigations from './components/DashboardNavigations';
import WorkQueue from './components/WorkQueue';
import PortfolioGoals from './components/PortfolioGoals';
import QuickActions from './components/QuickActions';
import MarketIntelligence from './components/MarketIntelligence';
import MyAccountsTable from './components/MyAccountsTable';

function App() {
  return (
    <div className="App">
      {/* ================= НОВИЙ ДВОРІВНЕВИЙ ХЕДЕР ================= */}
      <header className="page-header">
        {/* Верхній рядок хедера */}
        <div className="top-header">
          <h2 className="welcome-header">Hi Arthur, welcome! You have 12 open tasks.</h2>
          <div className="top-header-right">
            <input type="text" placeholder="Search" className="navbar-search" />
            <button className="navbar-avatar">AR</button>
          </div>
        </div>

        {/* Нижній рядок хедера (компонент навігації) */}
        <DashboardNavigations />
      </header>

      {/* ================= ОСНОВНИЙ КОНТЕНТ ================= */}
      <main className="dashboard-content">
        <WorkQueue />
        <PortfolioGoals />
        <div className="right-stack">
          <QuickActions />
          <MarketIntelligence />
        </div>
        <MyAccountsTable />
      </main>
    </div>
  );
}

export default App;