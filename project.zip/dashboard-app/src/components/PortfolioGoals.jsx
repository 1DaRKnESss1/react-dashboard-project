import React from 'react';
import './PortfolioGoals.css'; // Буде створено пізніше
import portfolioGoalsData from '../data/portfolioGoalsData.json'; // Буде створено пізніше

const PortfolioGoals = () => {
  return (
    <div className="dashboard-section portfolio-goals">
      <h3>Portfolio goals</h3>
      <div className="goals-list">
        {portfolioGoalsData.map((goal, index) => (
          <div key={index} className="goal-item">
            <div className="goal-header">
              <span className="goal-title">{goal.title}</span>
              {goal.target && <span className="goal-target">{goal.target}</span>}
            </div>
            <div className="progress-bar-container">
              {goal.segments ? (
                goal.segments.map((segment, segIndex) => (
                  <div
                    key={segIndex}
                    className="progress-bar-segment"
                    style={{ width: `${segment.percentage}%`, backgroundColor: segment.color }}
                  ></div>
                ))
              ) : (
                <div
                  className="progress-bar"
                  style={{ width: `${goal.progress}%`, backgroundColor: goal.color }}
                ></div>
              )}
              {goal.targetIndicatorPosition && (
                <div
                  className="target-indicator"
                  style={{ left: `${goal.targetIndicatorPosition}%` }}
                ></div>
              )}
            </div>
            <div className="goal-footer">
              <span className="goal-value">{goal.currentValue}</span>
              {goal.status && <span className="goal-status" style={{ color: goal.statusColor }}>{goal.status}</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PortfolioGoals; 