import React, { useState } from 'react';
import './MyAccountsTable.css'; // Буде створено пізніше
import myAccountsData from '../data/myAccountsData.json'; // Буде створено пізніше

const MyAccountsTable = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterActive, setFilterActive] = useState(false);
  const [sortOrder, setSortOrder] = useState(null); // 'asc', 'desc'

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleFilterClick = () => {
    setFilterActive(!filterActive);
  };

  const handleSortClick = (column) => {
    if (sortOrder === 'asc') {
      setSortOrder('desc');
    } else {
      setSortOrder('asc');
    }
    // Тут можна додати логіку сортування за відповідною колонкою
  };

  const filteredAccounts = myAccountsData.filter(account =>
    account.accountName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.line.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.broker.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="dashboard-section my-accounts">
      <h3>My accounts</h3>
      <div className="accounts-controls">
        <div className="search-filter-group">
          <input
            type="text"
            placeholder="Search"
            className="accounts-search"
            value={searchTerm}
            onChange={handleSearchChange}
          />
          <button
            className={`control-button ${filterActive ? 'active' : ''}`}
            onClick={handleFilterClick}
          >
            Filter
          </button>
        </div>
        <div className="sort-group-new">
          <button className="control-button" onClick={() => handleSortClick('sort')}>Sort</button>
          <button className="control-button">Group</button>
          <button className="control-button new-button">+ New</button>
        </div>
      </div>
      <div className="accounts-table">
        <table>
          <thead>
            <tr>
              <th>ACCOUNT NAME/TYPE</th>
              <th>LINE</th>
              <th>BROKER</th>
              <th>RENEWAL DATE</th>
              <th>PREMIUM</th>
              <th>RATED PREMIUM</th>
              <th>LOSS RATIO</th>
              <th>APPETITE</th>
              <th>STATUS</th>
              <th>TRIAGE</th>
              <th>WINNABILITY</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filteredAccounts.map((account, index) => (
              <tr key={index}>
                <td>
                  {account.accountName}
                  <br />
                  <small>{account.accountType}</small>
                </td>
                <td>{account.line}</td>
                <td>{account.broker}</td>
                <td>{account.renewalDate}</td>
                <td><span className="premium-value">{account.premium}</span></td>
                <td>{account.ratedPremium}</td>
                <td><span className={`loss-ratio-value ${account.lossRatioColor}`}>{account.lossRatio}</span></td>
                <td><span className={`appetite-value ${account.appetiteColor}`}>{account.appetite}</span></td>
                <td>
                  <span className={`status-dot ${account.status.toLowerCase().replace(/ /g, '-')}`}></span>
                  {account.status}
                </td>
                <td>{account.triage}</td>
                <td><span className={`winnability-value ${account.winnabilityColor}`}>{account.winnability}</span></td>
                <td>
                  <button className="info-button">...</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MyAccountsTable; 