import React, { useState } from 'react';
import './DashboardNavigations.css';
import { HiOutlineHome, HiOutlineOfficeBuilding, HiOutlineBriefcase, HiOutlineDocumentText, HiOutlineUserGroup, HiOutlineChartSquareBar, HiOutlineKey } from 'react-icons/hi';

const DashboardNavigations = () => {
  const [activeTab, setActiveTab] = useState('Dashboard');

  const navItems = [
    { label: 'Dashboard', icon: <HiOutlineHome /> },
    { label: 'Accounts', icon: <HiOutlineBriefcase /> },
    { label: 'Brokers', icon: <HiOutlineUserGroup /> },
    { label: 'Submissions', icon: <HiOutlineDocumentText /> },
    { label: 'Organizations', icon: <HiOutlineOfficeBuilding /> },
    { label: 'Goals & Rules', icon: <HiOutlineChartSquareBar /> },
    { label: 'Admin', icon: <HiOutlineKey /> },
  ];

  return (
    <nav className="dashboard-navigations">
      {/* Ліва частина, що тепер включає все, крім стрілок */}
      <div className="nav-items-left">
        
        {navItems.map((item) => (
          <button
            key={item.label}
            className={`nav-button ${activeTab === item.label ? 'active' : ''}`}
            onClick={() => setActiveTab(item.label)}
          >
            {item.icon} {item.label}
          </button>
        ))}
      </div>
      
      {/* Права частина - тільки стрілки */}
      <div className="nav-items-right">
        <button className="nav-arrow-button">←</button>
        <button className="nav-arrow-button">→</button>
      </div>
    </nav>
  );
};

export default DashboardNavigations;